# YOLOv5 Fall Detection > 2023-03-03 10:23pm
https://universe.roboflow.com/object-detection/yolov5-fall-detection

Provided by a Roboflow user
License: CC BY 4.0

